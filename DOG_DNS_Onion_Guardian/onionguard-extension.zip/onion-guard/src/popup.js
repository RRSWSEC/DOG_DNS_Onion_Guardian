/**
 * OnionGuard — popup.js
 *
 * Minimal popup controller.
 * Queries background for aggregate block count only — no URL data ever requested.
 */

"use strict";

// Detect Firefox vs Chrome API
const ext = typeof browser !== "undefined" ? browser : chrome;

const countEl  = document.getElementById("block-count");
const resetBtn = document.getElementById("reset-btn");

function fetchStatus() {
  ext.runtime.sendMessage({ type: "GET_STATUS" }, (response) => {
    if (chrome.runtime.lastError) return;
    if (response && typeof response.sessionBlocked === "number") {
      countEl.textContent = response.sessionBlocked.toLocaleString();
    }
  });
}

resetBtn.addEventListener("click", () => {
  ext.runtime.sendMessage({ type: "RESET_COUNTER" }, () => {
    countEl.textContent = "0";
  });
});

// Initial load
fetchStatus();
