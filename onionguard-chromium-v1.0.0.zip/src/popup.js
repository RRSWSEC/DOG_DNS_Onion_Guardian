/**
 * OnionGuard - popup.js (shared)
 * Compatible with both Firefox (browser.*) and Chrome/Opera (chrome.*)
 */

"use strict";

// Unified API shim - browser (Firefox) takes priority, falls back to chrome
var api = (typeof browser !== "undefined" && browser.runtime) ? browser : chrome;

var countEl  = document.getElementById("block-count");
var resetBtn = document.getElementById("reset-btn");

function fetchStatus() {
  try {
    var result = api.runtime.sendMessage({ type: "GET_STATUS" });
    // Promise-based (Firefox)
    if (result && typeof result.then === "function") {
      result.then(function(response) {
        if (response && typeof response.sessionBlocked === "number") {
          countEl.textContent = response.sessionBlocked.toLocaleString();
        }
      }).catch(function() {});
    }
  } catch (e) {
    // Callback-based fallback (Chrome/Opera)
    chrome.runtime.sendMessage({ type: "GET_STATUS" }, function(response) {
      if (chrome.runtime.lastError) return;
      if (response && typeof response.sessionBlocked === "number") {
        countEl.textContent = response.sessionBlocked.toLocaleString();
      }
    });
  }
}

resetBtn.addEventListener("click", function() {
  try {
    var result = api.runtime.sendMessage({ type: "RESET_COUNTER" });
    if (result && typeof result.then === "function") {
      result.then(function() {
        countEl.textContent = "0";
      }).catch(function() {});
    }
  } catch (e) {
    chrome.runtime.sendMessage({ type: "RESET_COUNTER" }, function() {
      if (chrome.runtime.lastError) return;
      countEl.textContent = "0";
    });
  }
});

fetchStatus();
