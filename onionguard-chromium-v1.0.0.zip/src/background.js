/**
 * OnionGuard - background.js
 * Manifest V3 Service Worker (Chrome, Chromium, Opera, Edge)
 *
 * Intercepts ALL network requests at the webRequest layer - before OS DNS
 * resolution - and cancels any request whose hostname resolves to .onion TLD.
 *
 * Privacy guarantees:
 *   * Zero request logging
 *   * Zero metadata retention
 *   * Only aggregate integer counter persisted - never URLs, hostnames, or timestamps
 *   * No external connections of any kind
 */

"use strict";

const ONION_PATTERN = /(?:^|\.)onion$/i;
let sessionBlockCount = 0;

// -- Intercept ------------------------------------------------------------------

function interceptRequest(details) {
  var hostname;
  try {
    hostname = new URL(details.url).hostname;
  } catch (e) {
    return undefined;
  }

  if (ONION_PATTERN.test(hostname)) {
    sessionBlockCount++;
    // Store only the aggregate count - hostname is discarded immediately
    chrome.storage.local.set({ totalBlocked: sessionBlockCount });
    return { cancel: true };
  }

  return undefined;
}

// -- Storage --------------------------------------------------------------------

function loadBlockCount() {
  chrome.storage.local.get("totalBlocked", function(result) {
    if (result && typeof result.totalBlocked === "number") {
      sessionBlockCount = result.totalBlocked;
    }
  });
}

// -- Messaging ------------------------------------------------------------------

chrome.runtime.onMessage.addListener(function(message, _sender, sendResponse) {
  if (message.type === "GET_STATUS") {
    sendResponse({ active: true, sessionBlocked: sessionBlockCount });
    return true;
  }
  if (message.type === "RESET_COUNTER") {
    sessionBlockCount = 0;
    chrome.storage.local.set({ totalBlocked: 0 });
    sendResponse({ ok: true });
    return true;
  }
});

// -- Init -----------------------------------------------------------------------

chrome.webRequest.onBeforeRequest.addListener(
  interceptRequest,
  { urls: ["<all_urls>"] },
  ["blocking"]
);

loadBlockCount();
