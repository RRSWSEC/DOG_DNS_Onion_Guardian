/**
 * OnionGuard - background.js
 * Manifest V2 Persistent Background Page (Firefox)
 *
 * Uses the `browser.*` promise-based WebExtension API.
 * Functionally identical to the MV3 variant but adapted for Firefox's API surface.
 *
 * Privacy guarantees:
 *   * Zero request logging
 *   * Zero metadata retention
 *   * Only aggregate integer counter persisted - never URLs, hostnames, or timestamps
 *   * No external connections of any kind
 */

"use strict";

var ONION_PATTERN = /(?:^|\.)onion$/i;
var sessionBlockCount = 0;

// -- Intercept ------------------------------------------------------------------

function interceptRequest(details) {
  var hostname;
  try {
    hostname = new URL(details.url).hostname;
  } catch (e) {
    return {};
  }

  if (ONION_PATTERN.test(hostname)) {
    sessionBlockCount++;
    // Store only the aggregate count - hostname discarded immediately
    browser.storage.local.set({ totalBlocked: sessionBlockCount });
    return { cancel: true };
  }

  return {};
}

// -- Storage --------------------------------------------------------------------

function loadBlockCount() {
  browser.storage.local.get("totalBlocked").then(function(result) {
    if (result && typeof result.totalBlocked === "number") {
      sessionBlockCount = result.totalBlocked;
    }
  }).catch(function() {});
}

// -- Messaging ------------------------------------------------------------------

browser.runtime.onMessage.addListener(function(message) {
  if (message.type === "GET_STATUS") {
    return Promise.resolve({ active: true, sessionBlocked: sessionBlockCount });
  }
  if (message.type === "RESET_COUNTER") {
    sessionBlockCount = 0;
    browser.storage.local.set({ totalBlocked: 0 });
    return Promise.resolve({ ok: true });
  }
});

// -- Init -----------------------------------------------------------------------

browser.webRequest.onBeforeRequest.addListener(
  interceptRequest,
  { urls: ["<all_urls>"] },
  ["blocking"]
);

loadBlockCount();
